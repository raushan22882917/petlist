<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

use RadiusTheme\Petslist\Helper;
use RadiusTheme\Petslist\Options;

$socials = Helper::socials();
$widget_areas = Options::$options['f3_widgets_area'];

$privacy_url = get_privacy_policy_url() ? get_privacy_policy_url() : home_url( '/privacy-policy/' );
$terms_url   = home_url( '/terms-and-conditions/' );
?>

<!--=====================================-->
<!--=        Footer 3 Area Start        =-->
<!--=====================================-->
<footer class="footer footer-style-3">

    <div class="footer-bottom">
        <div class="container">
            <div class="copyright-area justify-content-between align-items-center">
                <div class="copyright-left">
                    <p class="footer-copyright mb-0">
                        &copy; Copyright <?php echo esc_html( date( 'Y' ) ); ?> Studs 4 You &ndash; All Right Reserved
                    </p>
                </div>
                <div class="copyright-right">
                    <p class="footer-links footer-copyright mb-0">
                        <a href="<?php echo esc_url( $privacy_url ); ?>"><?php esc_html_e( 'Privacy Policy', 'petslist' ); ?></a><span class="footer-sep">|</span><a href="<?php echo esc_url( $terms_url ); ?>"><?php esc_html_e( 'Terms and Conditions', 'petslist' ); ?></a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</footer>
<!--=====================================-->
<!--=          Footer Area End          =-->
<!--=====================================-->    